# Tech Stack Setup Guide
**For AI Agent Capstone**

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│                   Frontend                          │
│          React/Next.js + TailwindCSS                │
│         Deployed on Vercel (Free Tier)              │
└──────────────────┬──────────────────────────────────┘
                   │
                   │ (HTTPS API Calls)
                   ▼
┌─────────────────────────────────────────────────────┐
│              Backend API                            │
│      Express.js (Node.js) or FastAPI (Python)       │
│    Deployed on Vercel Functions / Railway           │
└──────────────┬──────────────────────┬───────────────┘
               │                      │
               │                      │
     ┌─────────▼───────┐    ┌────────▼──────────┐
     │   PostgreSQL    │    │  Vector Database  │
     │  (Supabase)     │    │  (Pinecone/Supabase pgvector)
     └─────────────────┘    └───────────────────┘
               │
               │
     ┌─────────▼────────────┐
     │   LLM API Calls      │
     │  (Anthropic Claude)  │
     └──────────────────────┘
```

---

## 📦 Part 1: Backend Setup (Node.js + Express)

### Prerequisites
```bash
node --version  # v18+ required
npm --version   # v9+
```

### Step 1: Initialize Project
```bash
mkdir my-agent
cd my-agent
npm init -y
npm install express dotenv cors axios pino pino-pretty
npm install --save-dev typescript ts-node @types/node @types/express
```

### Step 2: Create TypeScript Config
```bash
npx tsc --init
# Update tsconfig.json:
# - Set "target": "ES2020"
# - Set "module": "commonjs"
# - Set "moduleResolution": "node"
# - Set "outDir": "./dist"
# - Set "rootDir": "./src"
```

### Step 3: Environment Variables
Create `.env`:
```bash
ANTHROPIC_API_KEY=sk-ant-...
DATABASE_URL=postgresql://user:pass@host:5432/dbname
PINECONE_API_KEY=...
PINECONE_INDEX_NAME=...
PORT=3000
NODE_ENV=development
```

Create `.env.example`:
```bash
ANTHROPIC_API_KEY=your_key_here
DATABASE_URL=postgresql://...
PINECONE_API_KEY=...
PINECONE_INDEX_NAME=...
PORT=3000
NODE_ENV=development
```

### Step 4: Basic Express Server
Create `src/index.ts`:
```typescript
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pino from 'pino';

dotenv.config();

const app = express();
const logger = pino();

app.use(cors());
app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Example: LLM call endpoint
app.post('/api/ask', async (req, res) => {
  const { query } = req.body;
  
  try {
    logger.info({ msg: 'Processing query', query });
    
    // Call Anthropic Claude (see AI Patterns section below)
    const response = await queryAgent(query);
    
    res.json({ response });
  } catch (error) {
    logger.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  logger.info(`Server running on port ${PORT}`);
});
```

### Step 5: Package.json Scripts
```json
{
  "scripts": {
    "dev": "ts-node src/index.ts",
    "build": "tsc",
    "start": "node dist/index.js",
    "test": "jest",
    "lint": "eslint src"
  }
}
```

---

## 🤖 Part 2: AI Patterns (Structured Outputs + RAG)

### Pattern 1: Structured LLM Call
Create `src/ai/structured-call.ts`:
```typescript
import Anthropic from "@anthropic-ai/sdk";

interface QueryResult {
  intent: string;
  confidence: number;
  entities: string[];
  suggested_action: string;
}

export async function structuredQuery(
  userQuery: string
): Promise<QueryResult> {
  const client = new Anthropic();
  
  const systemPrompt = `You are a query analyzer. Respond ONLY with valid JSON matching this structure:
{
  "intent": "one of: search, purchase, support, feedback",
  "confidence": 0.0-1.0,
  "entities": ["entity1", "entity2"],
  "suggested_action": "brief next step"
}`;

  const response = await client.messages.create({
    model: "claude-opus-4-1",
    max_tokens: 256,
    system: systemPrompt,
    messages: [
      {
        role: "user",
        content: userQuery,
      },
    ],
  });

  const textContent = response.content.find((b) => b.type === "text");
  if (!textContent || textContent.type !== "text") {
    throw new Error("No text response from Claude");
  }

  return JSON.parse(textContent.text);
}

// Usage in Express route:
app.post("/api/analyze", async (req, res) => {
  const { query } = req.body;
  const result = await structuredQuery(query);
  res.json(result);
});
```

### Pattern 2: Retry Logic + Cost Tracking
Create `src/ai/call-with-retry.ts`:
```typescript
import Anthropic from "@anthropic-ai/sdk";
import pino from "pino";

const logger = pino();

interface CallMetrics {
  input_tokens: number;
  output_tokens: number;
  total_cost: number; // in cents
}

const COST_PER_MTK = 0.03; // $0.03 per million input tokens (example)
const COST_PER_MOUT = 0.06; // $0.06 per million output tokens (example)

export async function callWithRetry(
  userMessage: string,
  systemPrompt: string,
  maxRetries = 3
): Promise<{ response: string; metrics: CallMetrics }> {
  const client = new Anthropic();
  let lastError;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const response = await client.messages.create({
        model: "claude-opus-4-1",
        max_tokens: 1024,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }],
      });

      const textContent = response.content.find((b) => b.type === "text");
      if (!textContent || textContent.type !== "text") {
        throw new Error("No text response");
      }

      // Calculate cost
      const inputTokens = response.usage.input_tokens;
      const outputTokens = response.usage.output_tokens;
      const inputCost = (inputTokens / 1000000) * COST_PER_MTK * 100; // to cents
      const outputCost = (outputTokens / 1000000) * COST_PER_MOUT * 100; // to cents
      const totalCost = inputCost + outputCost;

      const metrics = {
        input_tokens: inputTokens,
        output_tokens: outputTokens,
        total_cost: totalCost,
      };

      logger.info({
        msg: "LLM call succeeded",
        attempt,
        metrics,
      });

      return { response: textContent.text, metrics };
    } catch (error) {
      lastError = error;
      const backoffMs = Math.pow(2, attempt) * 1000; // exponential backoff
      logger.warn({
        msg: "LLM call failed, retrying",
        attempt,
        backoffMs,
        error: (error as Error).message,
      });
      await new Promise((r) => setTimeout(r, backoffMs));
    }
  }

  throw lastError;
}
```

### Pattern 3: Simple RAG (Retrieval-Augmented Generation)
Create `src/ai/rag.ts`:
```typescript
import { Pinecone } from "@pinecone-database/pinecone";
import { CohereClient } from "cohere-ai";

const pinecone = new Pinecone();
const cohere = new CohereClient({ token: process.env.COHERE_API_KEY });

export async function retrieveContext(query: string, topK = 3) {
  // Step 1: Embed the query
  const embedResponse = await cohere.embed({
    texts: [query],
    model: "embed-english-v3.0",
  });

  const queryEmbedding = embedResponse.embeddings[0];

  // Step 2: Query vector database
  const index = pinecone.index("my-index");
  const results = await index.query({
    vector: queryEmbedding,
    topK,
    includeMetadata: true,
  });

  // Step 3: Extract and format context
  const context = results.matches
    .map((match) => `Source: ${match.metadata?.source}\n${match.metadata?.text}`)
    .join("\n---\n");

  return context;
}

export async function ragQuery(userQuery: string) {
  const context = await retrieveContext(userQuery);

  const systemPrompt = `You are a helpful assistant. Use the provided context to answer questions.
Context:
${context}`;

  // Call LLM with context
  const result = await callWithRetry(userQuery, systemPrompt);
  return result;
}
```

---

## 🎨 Part 3: Frontend Setup (React + Next.js)

### Step 1: Create Next.js App
```bash
npx create-next-app@latest my-agent-web --typescript --tailwind
cd my-agent-web
npm install axios zustand
```

### Step 2: Environment Variables
Create `.env.local`:
```bash
NEXT_PUBLIC_API_URL=http://localhost:3000
```

### Step 3: Basic Agent UI
Create `app/page.tsx`:
```typescript
'use client';

import { useState } from 'react';
import axios from 'axios';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // Add user message
    setMessages((prev) => [...prev, { role: 'user', content: input }]);
    setInput('');
    setLoading(true);

    try {
      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL}/api/ask`,
        { query: input }
      );

      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: response.data.response },
      ]);
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Error: Failed to get response' },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-sm px-4 py-2 rounded-lg ${
                msg.role === 'user'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-300 text-black'
              }`}
            >
              {msg.content}
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-4 border-t">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask me anything..."
            className="flex-1 px-4 py-2 border rounded-lg focus:outline-none"
            disabled={loading}
          />
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50"
          >
            {loading ? 'Sending...' : 'Send'}
          </button>
        </div>
      </form>
    </div>
  );
}
```

---

## 🗄️ Part 4: Database Setup (Supabase)

### Step 1: Create Supabase Project
1. Go to [supabase.com](https://supabase.com)
2. Create new project
3. Copy connection string

### Step 2: Install Client
```bash
npm install @supabase/supabase-js
```

### Step 3: Create Tables (SQL in Supabase Dashboard)
```sql
-- Users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT now()
);

-- Agent interactions (conversation history)
CREATE TABLE interactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  query TEXT NOT NULL,
  response TEXT,
  tokens_used INT,
  cost_cents DECIMAL(10, 4),
  created_at TIMESTAMP DEFAULT now()
);

-- Vector embeddings (for RAG)
CREATE TABLE embeddings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source TEXT,
  text TEXT,
  embedding vector(1536),
  created_at TIMESTAMP DEFAULT now()
);

-- Create index for fast similarity search
CREATE INDEX ON embeddings USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
```

---

## 🚀 Part 5: Deployment

### Deploy Backend (Vercel)
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Set environment variables in Vercel dashboard
# ANTHROPIC_API_KEY, DATABASE_URL, etc.
```

### Deploy Frontend (Vercel)
```bash
cd my-agent-web
vercel
```

Update `.env.local` to point to production API:
```bash
NEXT_PUBLIC_API_URL=https://my-agent-api.vercel.app
```

### Optional: Custom Domain
1. Buy domain (Vercel Domains, Namecheap, GoDaddy)
2. Point DNS to Vercel
3. Set in Vercel project settings

---

## 📊 Monitoring & Logging

### Log Rotation (Pino)
Create `src/logger.ts`:
```typescript
import pino from 'pino';

export const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  transport: {
    target: 'pino-pretty',
    options: {
      colorize: true,
      singleLine: false,
    },
  },
});
```

### Error Tracking (Optional: Sentry)
```bash
npm install @sentry/node
```

```typescript
import * as Sentry from "@sentry/node";

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
});

// Wrap Express middleware
app.use(Sentry.Handlers.requestHandler());
app.use(Sentry.Handlers.errorHandler());
```

---

## 📋 Checklist

- [ ] Node.js v18+ installed
- [ ] Express server running locally (`npm run dev`)
- [ ] `.env` file created with API keys
- [ ] Database connected (Supabase)
- [ ] LLM call working (test with curl or Postman)
- [ ] Next.js frontend running (`npm run dev` in web folder)
- [ ] Frontend → Backend API calls working
- [ ] Deployed to Vercel (backend + frontend)
- [ ] Custom domain configured (optional)
- [ ] Monitoring/logging set up

---

## 🆘 Troubleshooting

**Q: "Cannot find module 'axios'"**  
A: Run `npm install axios`

**Q: CORS errors from frontend**  
A: Check backend has `app.use(cors())` and frontend has correct `NEXT_PUBLIC_API_URL`

**Q: Anthropic API 401 error**  
A: Verify `ANTHROPIC_API_KEY` in `.env` is correct and has no extra spaces

**Q: Database connection refused**  
A: Check `DATABASE_URL` in `.env` and ensure Supabase project is running

**Q: Vector search not working**  
A: Ensure `embeddings` table has pgvector extension enabled in Supabase

---

## 📚 Additional Resources

- [Express.js Guide](https://expressjs.com/)
- [Next.js Docs](https://nextjs.org/docs)
- [Supabase Guide](https://supabase.com/docs)
- [Anthropic API Reference](https://docs.anthropic.com/)
- [Vercel Deployment](https://vercel.com/docs)
