# AI Stack Capstone: Master AI, Build Brand, Ship Agent
**Course**: Backend AI Engineering (Advanced Track)  
**Duration**: 8 weeks (2 months)  
**Level**: Intermediate → Advanced  
**Final Deliverable**: Deployed agent + portfolio website + GitHub presence

---

## 📋 Assignment Overview

This capstone consolidates your AI stack knowledge into three interconnected projects:

1. **AI Stack Mastery** — Deepen LLM/RAG/Agent fundamentals through hands-on work
2. **Personal Brand Website** — Showcase your work with a polished, SEO-friendly portfolio
3. **Shipped Agent Product** — Deploy a working agent that solves a real problem

All three ship together as your capstone. The website features the agent. The agent demonstrates your AI skills. Your GitHub/brand amplifies both.

---

## 🎯 Learning Objectives

By the end, you will:
- [ ] Master prompt engineering & LLM API patterns (structured outputs, retries, cost logging)
- [ ] Build production RAG & agentic systems (context retrieval, tool use, error handling)
- [ ] Design & deploy a full-stack agent (backend, frontend, database)
- [ ] Create a professional personal brand (website, docs, GitHub presence)
- [ ] Ship a working product to production (deployment, monitoring, iteration)

---

## 📅 Timeline & Phases

### Phase 1: Foundation & Planning (Weeks 1–2)
**Goal**: Establish AI stack knowledge & define your agent idea

- [ ] **Week 1: AI Fundamentals Sprint**
  - LLM basics: tokenization, context windows, cost models
  - Prompt engineering: zero-shot, few-shot, chain-of-thought
  - RAG fundamentals: embeddings, retrieval, ranking
  - Read: OpenAI docs, Anthropic cookbook, LlamaIndex primer
  - **Deliverable**: "AI Stack Study Guide" (1-2 page cheat sheet + 3 example prompts)

- [ ] **Week 2: Agent & Brand Definition**
  - Agent capability matrix: what will your agent do?
  - Brand pillars: your unique value (skills, perspective, niche)
  - Tech stack decision: Node/TS (FlyRank), Python (alternatives), deployment target
  - **Deliverable**: Agent PRD + Brand Statement + Tech Stack Doc

---

### Phase 2: AI Stack Deep Dive (Weeks 3–4)
**Goal**: Implement core AI patterns that your agent will use

- [ ] **Week 3: Structured Outputs & Cost Optimization**
  - Build a prompt + LLM call that returns strict JSON (e.g., Q&A extraction, intent classification)
  - Implement retry logic with exponential backoff
  - Log token counts & costs; track API budget
  - **Deliverable**: Module with structured LLM calls + cost dashboard (simple HTML table)

- [ ] **Week 4: RAG Pipeline**
  - Choose corpus: web scrape, docs, Q&A database, or custom
  - Implement: embed → store → retrieve → rank
  - Test retrieval quality (recall@k, precision)
  - **Deliverable**: Working RAG system with retriever unit tests + retrieval quality report

---

### Phase 3: Agent Build (Weeks 5–6)
**Goal**: Construct your agent MVP

- [ ] **Week 5: Core Agent Architecture**
  - Design agent loop: observe → think → act → repeat
  - Implement tool calling (2–4 tools that agent can invoke)
  - Error handling, context management, token budgeting
  - **Deliverable**: Agent system with logging + manual test suite

- [ ] **Week 6: Integration & Polish**
  - Connect RAG to agent (if applicable)
  - Add user input handling (web form or API)
  - Deploy to staging (Vercel, Railway, or internal server)
  - **Deliverable**: Functional agent accessible via web; passing integration tests

---

### Phase 4: Personal Brand & Website (Weeks 5–6, parallel)
**Goal**: Build a professional home for your work

- [ ] **Week 5: Website Core**
  - Clean homepage: bio, headline, value prop (60 words max)
  - Projects section with links & images
  - Agent demo (embedded iframe or link to live version)
  - Blog/posts (2–3 pieces on AI, agent design, or learnings)
  - **Tech**: React/Next.js, TailwindCSS, or similar; host on Vercel/Netlify
  - **Deliverable**: Live portfolio at custom domain (e.g., zoya.dev or yourname-ai.vercel.app)

- [ ] **Week 6: Brand Polish**
  - SEO: meta tags, Open Graph images, structured data (schema.org)
  - Social links: GitHub, LinkedIn, Twitter
  - About page (1–2 min read): your journey, why AI, current focus
  - Contact form or email link
  - **Deliverable**: SEO audit report + social media optimized images

---

### Phase 5: Documentation & Launch (Week 7–8)
**Goal**: Ship everything with solid docs & visibility

- [ ] **Week 7: Documentation**
  - **README**: Agent overview, setup, usage examples, limitations
  - **API docs**: If applicable, endpoints, request/response examples, error codes
  - **Blog post**: "Building [Agent Name]" — your approach, learnings, code snippets
  - **GitHub repo**: Public, well-organized (src/, tests/, docs/, .env.example)
  - **Deliverable**: GitHub repo with 50+ stars target (share in communities)

- [ ] **Week 8: Launch & Iteration**
  - Share on:
    - Dev communities (ProductHunt, Show HN, Indie Hackers)
    - Your social media + personal brand channels
    - Relevant Slack/Discord communities
  - Gather feedback; fix bugs & improve UX
  - Track: traffic to website, agent usage, GitHub engagement
  - **Deliverable**: Launch summary + metrics (page views, agent calls, feedback log)

---

## 📦 Deliverables Checklist

### Code & Systems
- [ ] Structured LLM call module (JSON output, retry, cost logging)
- [ ] RAG pipeline (embedder, vector store, retriever, ranker)
- [ ] Agent system (loop, tools, state management, error handling)
- [ ] Web backend (API, database, auth if needed)
- [ ] Web frontend (agent UI, chat or form-based)
- [ ] Deployment pipeline (GitHub Actions, env config, logging)

### Brand & Docs
- [ ] Personal website (live, SEO-optimized, mobile-friendly)
- [ ] Agent README + API documentation
- [ ] Blog post (2,000+ words) explaining the project
- [ ] GitHub repo with meaningful commit history
- [ ] Launch post (ProductHunt, HN, or similar)

### Artifacts & Reports
- [ ] AI Stack Study Guide (week 1)
- [ ] Agent PRD + Brand Statement (week 2)
- [ ] Cost optimization dashboard (week 3)
- [ ] Retrieval quality report (week 4)
- [ ] Integration test results (week 6)
- [ ] SEO audit report (week 6)
- [ ] Launch metrics & feedback log (week 8)

---

## ✅ Success Criteria

| Criterion | Target | Weight |
|-----------|--------|--------|
| **AI Stack** | Structured outputs, RAG, agent patterns implemented correctly | 30% |
| **Agent Functionality** | Works reliably; handles 10+ use cases or queries correctly | 25% |
| **Website Quality** | Polished design, mobile-friendly, SEO scores >80 | 20% |
| **Documentation** | Clear README, API docs, blog post (2k+ words) | 15% |
| **Launch & Engagement** | >50 GitHub stars, 100+ website visitors, 1+ community share | 10% |

---

## 🛠️ Tech Stack Recommendations

### Backend AI
- **LLM Provider**: Anthropic Claude API (your FlyRank choice)
- **LLM Framework**: LangChain, LlamaIndex, or custom (Node.js)
- **Embeddings**: OpenAI, Cohere, or local (sentence-transformers)
- **Vector DB**: Pinecone, Weaviate, Supabase (pgvector), or Qdrant
- **Runtime**: Node.js 18+ (TypeScript) or Python 3.10+

### Backend API
- **Framework**: Express.js (Node) or FastAPI (Python)
- **Database**: PostgreSQL (Supabase) or MongoDB (Atlas)
- **Auth**: (Optional) Clerk, Auth0, or custom JWT
- **Logging**: Pino (Node) or Loguru (Python); send to LogTail or DataDog

### Frontend
- **Framework**: React + Next.js (recommended) or Vue/Svelte
- **Styling**: TailwindCSS or CSS Modules
- **UI**: shadcn/ui or Headless UI for components
- **Hosting**: Vercel (Next.js native), Netlify, or Railway

### Deployment
- **API**: Vercel Functions, Railway, Heroku, AWS Lambda
- **Database**: Supabase, AWS RDS, MongoDB Atlas
- **Vector DB**: Pinecone (managed), Supabase pgvector (integrated)
- **Monitoring**: Sentry, LogTail, or built-in logging

---

## 📚 Resources & References

### AI Stack Learning
- [Anthropic Cookbook](https://github.com/anthropics/cookbook) — Prompt engineering, vision, structured outputs
- [LangChain Docs](https://js.langchain.com/) — Agent patterns, RAG frameworks
- [LlamaIndex](https://docs.llamaindex.ai/) — RAG, vector stores, evaluation
- [OpenAI Prompt Engineering Guide](https://platform.openai.com/docs/guides/prompt-engineering)

### Agent Design
- [Building Effective Agents](https://www.anthropic.com/research/agents) — Anthropic research
- [React Pattern](https://arxiv.org/abs/2210.03629) — Agent reasoning framework
- [LATS (Language Agent Tree Search)](https://arxiv.org/abs/2310.04406) — Advanced agent planning

### Web & Brand
- [Web Vitals](https://web.dev/vitals/) — Performance metrics
- [SEO Starter Guide](https://developers.google.com/search/docs) — Google's official guide
- [Vercel Deployment Best Practices](https://vercel.com/docs)

### Deployment & Monitoring
- [12 Factor App](https://12factor.net/) — Best practices for scalable apps
- [Sentry Docs](https://docs.sentry.io/) — Error tracking & monitoring

---

## 🎓 Grading Rubric

### AI Stack Mastery (30%)
- **Full (27–30)**: Structured outputs, RAG, and agent patterns correctly implemented; cost optimized; production-ready error handling
- **Good (24–26)**: All patterns present; minor inefficiencies; solid error handling
- **Okay (21–23)**: Patterns mostly work; some gaps in robustness or optimization
- **Needs Work (<21)**: Missing patterns or significant bugs

### Agent Functionality (25%)
- **Full (23–25)**: Agent reliably handles 10+ complex queries; graceful error handling; tested edge cases
- **Good (20–22)**: Handles most queries well; minor bugs or limited edge cases
- **Okay (17–19)**: Basic functionality works; fragile or limited scope
- **Needs Work (<17)**: Unreliable or very limited functionality

### Website & Brand (20%)
- **Full (18–20)**: Polished design, mobile-responsive, SEO score >85, custom domain, fast loading (<2s)
- **Good (16–17)**: Clean design, responsive, SEO >75, decent speed
- **Okay (14–15)**: Functional but rough edges; SEO ~60; slow
- **Needs Work (<14)**: Unpolished, poor mobile UX, minimal SEO

### Documentation (15%)
- **Full (14–15)**: Excellent README, API docs, 2k+ word blog post, clear commit history
- **Good (12–13)**: Good README, basic API docs, 1.5k+ word post
- **Okay (10–11)**: Minimal docs, short post
- **Needs Work (<10)**: Poor or missing documentation

### Launch & Engagement (10%)
- **Full (9–10)**: >50 GitHub stars, 500+ website visitors, 2+ community shares, positive feedback
- **Good (7–8)**: 30+ stars, 300+ visitors, 1 community share
- **Okay (5–6)**: <30 stars, 100+ visitors, minimal engagement
- **Needs Work (<5)**: Minimal launch effort

---

## 💡 Project Ideas (Pick One)

### Tier 1: High Impact
1. **Customer Support Agent** — FAQ resolver + ticket classifier; learns from docs
2. **Code Reviewer Agent** — Analyzes pull requests; suggests improvements
3. **Product Recommender Agent** — Personalized suggestions from user queries + product DB
4. **Research Assistant** — Reads papers/articles; extracts insights; answers Q&A

### Tier 2: Creative
5. **Writing Coach Agent** — Analyzes writing; gives feedback on style, clarity, tone
6. **Interview Prep Agent** — Mock interviews; evaluates answers; tailored tips
7. **Job Match Agent** — Analyzes resumes + jobs; scores compatibility + advice
8. **Content Creator Agent** — Generates & optimizes social media posts

### Tier 3: Niche/Fun
9. **Game Design Assistant** — Generates game ideas; balances mechanics; brainstorms
10. **Travel Planner Agent** — Builds itineraries; suggests activities; tracks budget
11. **Recipe Creator** — Builds recipes from ingredients; adapts for diets/preferences
12. **Debate Coach** — Generates arguments; fact-checks claims; teaches reasoning

**Recommendation**: Pick something **you'd actually use** or **your friends would ask for**. That motivation carries through 8 weeks.

---

## 🚀 Getting Started

1. **This Week**: Decide on your agent idea + personal brand angle
2. **Next Week**: Start AI fundamentals sprint + design your brand
3. **Weeks 3–8**: Execute phases; ship incrementally
4. **Week 8**: Launch & celebrate

**Checkpoint meetings**: Weeks 2, 4, 6, 8 (15 min each) to share progress & unblock.

---

## ❓ FAQ

**Q: Can I use existing code/libraries?**  
A: Yes! RAG, agents, and deployment need external libraries. But your agent logic & website must be original.

**Q: What if my agent idea is too ambitious?**  
A: Scope it down. An agent that does 2 things exceptionally well beats one that does 10 things poorly. Save stretch features for post-launch.

**Q: Do I need a custom domain for the website?**  
A: Not required, but encouraged. Vercel free tier gives `yourname.vercel.app`. A .dev domain (~$12/year) is cheap and looks pro.

**Q: How much does deployment cost?**  
A: Keep it minimal:
- Vercel/Netlify: Free tier handles most traffic
- Supabase: Free tier includes 500K tokens/month vector storage
- Pinecone: Free tier has limits; $0.04/1K requests if you exceed
- **Budget**: $15–30/month if you scale beyond free tiers

**Q: Can this be a team project?**  
A: Yes, but scope scales up. Each person owns one phase (e.g., one handles AI, one handles web, one handles brand). Commit history must show balanced contributions.

---

## 📞 Support

- **Office Hours**: Weekly Zoom
- **Discord**: `#capstone-ai-agent` channel
- **Feedback Loop**: Week 2, 4, 6, 8 checkpoints + anytime Slack
- **Resources**: Shared folder with templates, boilerplate, example agents

Good luck! 🚀
