# Agent PRD Template
**Use this template to define your agent idea**

---

## 1. Executive Summary

**Agent Name**: [Name of your agent]

**One-Liner**: A [type] agent that helps users [core job to be done].

*Example: "A customer support agent that resolves FAQs instantly and escalates complex issues to human agents."*

---

## 2. Problem Statement

**What problem does this solve?**
- Describe the pain point in 2–3 sentences
- Who experiences this pain? (target user)
- How painful is it? (frequency, impact)

*Example:*
> *Customers wait 24–48 hours for support responses. For urgent issues, this causes churn. Support teams are overwhelmed with repetitive FAQ questions.*

**Why now?**
- What changed that makes this solvable now? (LLMs, data availability, etc.)

---

## 3. Solution Overview

**How does your agent solve this?**
- High-level description (2–3 sentences)
- How is it different from existing solutions?

*Example:*
> *This agent reads your knowledge base and answers customer questions in <5 seconds with 95% accuracy. For queries it can't handle, it generates a summary for human agents.*

---

## 4. Core Features

List 3–5 core capabilities. For each, include:
- **Feature**: What it does
- **Input**: What users provide
- **Output**: What they get back
- **Complexity**: Low / Medium / High

| Feature | Input | Output | Complexity |
|---------|-------|--------|------------|
| FAQ Resolution | Customer question | Relevant answer + confidence | Low |
| Ticket Classification | Issue description | Category + urgency + routing | Medium |
| Escalation Detection | Conversation flow | "Escalate to human?" yes/no | Medium |
| | | | |

---

## 5. Limitations

**What will your agent NOT do?**
- Be honest about boundaries
- This makes users trust you more

*Example:*
- Won't process payment information (security risk)
- Won't handle multi-turn troubleshooting (requires human intuition)
- Won't access real-time inventory (if not integrated)

---

## 6. User Flow

**How will users interact with your agent?**

```
User Input
    ↓
Agent Receives Query
    ↓
Agent Retrieves Context (RAG)
    ↓
Agent Thinks (LLM)
    ↓
Agent Chooses Action (tool use)
    ↓
Agent Executes Tool (if needed)
    ↓
Agent Responds to User
```

**Detailed steps**:
1. User types/asks question
2. Agent classifies intent
3. Agent retrieves relevant docs/context
4. Agent formulates response (or calls tool)
5. Agent delivers answer + confidence + alternative actions

---

## 7. Technical Architecture (High-Level)

```
Frontend (Chat UI)
        ↓
Backend API (Agent Loop)
        ↓
        ├→ Vector DB (Retrieval)
        ├→ LLM API (Thinking)
        └→ Tools (Execution)
```

**Key components**:
- **Frontend**: Chat interface (React, Next.js)
- **Backend**: Agent loop + tool runner (Node.js, Python)
- **Retrieval**: Vector database + embeddings (Pinecone, Supabase)
- **LLM**: Claude API (Anthropic)
- **Tools**: Integrations (search, database queries, APIs)

---

## 8. Data & Training

**What data will your agent use?**
- Knowledge base source (docs, FAQs, products, etc.)
- Data size: ~[100 docs, 1000 Q&A pairs, etc.]
- Update frequency: Real-time / Daily / Weekly

**Will you fine-tune?**
- No (for most agents starting out—use RAG instead)

---

## 9. Success Metrics

**How will you measure if your agent succeeds?**

| Metric | Target | How to Measure |
|--------|--------|----------------|
| Answer Accuracy | >90% | Manual review of 50 random responses |
| Response Time | <2 sec | Log API latency |
| User Satisfaction | >4.0/5 | In-app rating (optional) |
| Cost Efficiency | <$0.01/query | Track token usage |
| Escalation Rate | <20% | % of queries escalated to human |

---

## 10. Go-to-Market

**How will you launch this?**

1. **Phase 1** (Week 1–4): Build MVP
   - Core agent logic
   - Live demo link on website

2. **Phase 2** (Week 5–6): Polish
   - Error handling
   - Documentation

3. **Phase 3** (Week 7–8): Launch
   - ProductHunt submission
   - Social media share
   - Community outreach

**Target audience**:
- [Company type / user group]
- [Size of market]

---

## 11. Competitive Landscape

**What already exists?**
- [Competitor 1]: Costs $X/month, does Y, missing Z
- [Competitor 2]: Open-source, does Y, missing Z

**Why your agent is better**:
- [Unique advantage 1]
- [Unique advantage 2]

---

## 12. Risks & Mitigation

| Risk | Severity | Mitigation |
|------|----------|-----------|
| LLM makes mistakes | High | Add human-in-the-loop for escalations |
| Slow response time | Medium | Cache common queries |
| High API costs | Medium | Implement cost limits + monitoring |
| Poor RAG quality | Medium | Build evaluation framework in Week 4 |

---

## 13. Timeline

**8-week breakdown**:
- **Week 1–2**: Learn AI stack + define agent
- **Week 3–4**: Build core AI patterns (structured outputs, RAG)
- **Week 5–6**: Build agent + website
- **Week 7–8**: Polish + launch

---

## 14. Open Questions

**What do you need to figure out?**
- Resolved ✓
- Resolved ✓
- **[Q1]**: Resolution strategy?
- **[Q2]**: How to handle ...?

---

## Example: Customer Support Agent

```markdown
# Customer Support Agent

## Executive Summary
Name: SupportBot
One-liner: "An AI customer support agent that resolves FAQs in <5 seconds 
and escalates complex issues to humans for resolution."

## Problem Statement
**Pain**: Customers wait 24–48 hours for support; 60% of tickets are 
repetitive FAQs.

**Why now**: Claude's improved reasoning + ability to handle long contexts 
makes knowledge-base retrieval practical for real companies.

## Features
1. **FAQ Resolution**: User question → relevant answer + confidence (Low)
2. **Ticket Classification**: Issue → category + urgency (Medium)
3. **Context Retrieval**: Finds relevant docs from knowledge base (Medium)
4. **Escalation**: Detects human-needed issues (Medium)

## Success Metrics
- Accuracy: >90% (manual eval on 50 responses)
- Response time: <2s
- User satisfaction: >4.0/5
- Cost: <$0.01/query

## Timeline
- Weeks 1–2: Define + learn
- Weeks 3–4: RAG pipeline
- Weeks 5–6: Agent + website
- Weeks 7–8: Launch + iterate
```

---

## Notes

- **Keep it real**: You can't build everything. Scope ruthlessly.
- **Iterate**: Your PRD will change as you learn. That's OK.
- **Measure**: Pick 2–3 metrics you'll actually track.
- **Ship**: A good agent that ships beats a perfect agent that doesn't.

Good luck! 🚀
